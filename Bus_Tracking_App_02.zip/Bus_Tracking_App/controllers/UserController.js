const { User } = require("../models"); // Ensure path is correct
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { Sequelize } = require("sequelize");

// GET all users
const getAllUsers = async (req, res) => {
  try {
    const users = await User.findAll();
    res.status(200).json(users);
  } catch (error) {
    res.status(500).send({
      message: error.message || "Some error occurred while retrieving users.",
    });
  }
};

// GET users by name substring
const getUsersByName = async (req, res) => {
  try {
    const nameSubstring = req.params.name;
    const users = await User.findAll({
      where: {
        name: {
          [Sequelize.Op.like]: `%${nameSubstring}%`,
        },
      },
    });
    if (users.length > 0) {
      res.status(200).json(users);
    } else {
      res.status(404).send({
        message: `No users found containing the name substring: ${nameSubstring}`,
      });
    }
  } catch (error) {
    res.status(500).send({
      message: "Error retrieving users with name substring=" + nameSubstring,
    });
  }
};

// POST a new user (Signup)
const createUser = async (req, res) => {
  try {
    const { name, email, password, user_type } = req.body;
    if (!email || !name || !password || !user_type) {
      res.status(400).send({ message: "Content cannot be empty!" });
      return;
    }

    // Check if user already exists
    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      res.status(400).send({ message: "Email is already in use!" });
      return;
    }

    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create the user
    const newUser = await User.create({
      name,
      email,
      password: hashedPassword,
      user_type,
    });
    res.status(201).json(newUser);
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: "Some error occurred while creating the user." });
  }
};

// POST to login a user
const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      res.status(400).send({ message: "Content cannot be empty!" });
      return;
    }

    // Find the user by email
    const user = await User.findOne({ where: { email } });
    if (!user) {
      res.status(404).send({ message: "User not found!" });
      return;
    }

    // Check the password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      res.status(400).send({ message: "Invalid credentials!" });
      return;
    }
    const { user_id, user_type } = user.dataValues;
    console.log(user_id, user_type);
    const token = jwt.sign(
      { id: user_id, user_type },
      "secret",
      { expiresIn: "1h" }
    );

    res.status(200).json({ user, token });
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: "Some error occurred while logging in." });
  }
};

// DELETE a user
const deleteUser = async (req, res) => {
  try {
    // Extract the Authorization header
    const header = req.headers.authorization;
    if (!header) {
      return res.status(401).send({ message: "Authorization token is missing." });
    }

    // Extracting the token from the Authorization header (assuming 'Bearer your_token_here')
    const parts = header.split(' ');
    if (parts.length !== 2 || parts[0] !== 'Bearer') {
      return res.status(401).send({ message: "Authorization header is malformed." });
    }
    const token = parts[1];  // The token is expected to be the second part

    // Verifying the token
    const decoded = jwt.verify(token, 'secret');

    // Extract user ID from token using the correct key, which is 'id' based on your token signing process
    const userId = decoded.id;
    if (!userId) {
      return res.status(400).send({ message: "Token does not contain the user ID." });
    }

    // Attempt to delete the user
    const deleted = await User.destroy({
      where: { user_id: userId }
    });

    if (deleted) {
      res.status(200).send({ 
        message: "User was deleted successfully!" 
      });
    } else {
      res.status(404).send({
        message: `Cannot delete user with id=${userId}. Maybe user was not found!`
      });
    }
  } catch (error) {
    if (error.name === 'JsonWebTokenError' || error.name === 'TokenExpiredError') {
      res.status(401).send({ message: "Invalid or expired token" });
    } else {
      res.status(500).send({ message: "Could not delete user with token provided: " + error.message });
    }
  }
};

// PUT to update a user
const updateUser = async (req, res) => {
  try {
    const token = req.headers.authorization.split(" ")[1]; // Assuming the token is sent in the Authorization header
    const decoded = jwt.verify(token, "secret"); // Replace 'secret' with your actual secret key used for signing the tokens

    const userId = decoded.id; // Extract user ID from token
    const updated = await User.update(req.body, {
      where: { user_id: userId },
    });

    if (updated[0] > 0) {
      res.status(200).send({ message: "User was updated successfully." });
    } else {
      res.status(404).send({
        message: `Cannot update user with id=${userId}. Maybe user was not found or req.body is empty!`,
      });
    }
  } catch (error) {
    if (error.name === "JsonWebTokenError") {
      // Handle invalid token
      res.status(401).send({ message: "Invalid token" });
    } else {
      // Handle other errors
      res.status(500).send({
        message: "Error updating user with token provided: " + error.message,
      });
    }
  }
};

module.exports = {
  getAllUsers,
  createUser,
  loginUser,
  deleteUser,
  updateUser,
  getUsersByName,
};
