const express = require('express');
const router = express.Router();
const userController = require('../controllers/UserController');

router.get('/', userController.getAllUsers);
router.get('/:name', userController.getUsersByName);
router.post('/Signup', userController.createUser);
router.delete('/', userController.deleteUser);
router.patch('/:id', userController.updateUser);
router.post('/login', userController.loginUser);

module.exports = router;
