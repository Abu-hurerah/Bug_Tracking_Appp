const { DataTypes, Model } = require("sequelize");

class ProjectAssignment extends Model {}

module.exports = (sequelize) => {
  ProjectAssignment.init(
    {
      project_id: {
        type: DataTypes.INTEGER,
        references: {
          model: 'projects',  // Table names are usually lowercase.
          key: 'project_id'
        },
        primaryKey: true
      },
      user_id: {
        type: DataTypes.INTEGER,
        references: {
          model: 'users',  // Make sure this matches the actual table name in your DB.
          key: 'user_id'
        },
        primaryKey: true
      }
    },
    {
      sequelize,
      tableName: "projectassignments",  // Typically, table names are lowercase.
      timestamps: false
    }
  );

  return ProjectAssignment;
};
