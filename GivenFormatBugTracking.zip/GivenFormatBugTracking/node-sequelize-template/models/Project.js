const { DataTypes, Model } = require("sequelize");

class Project extends Model {}

module.exports = (sequelize) => {
  Project.init(
    {
      project_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false
      },
      manager_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: 'users',  // Ensure this matches the table name used in DB, often lowercase.
          key: 'id'  // Make sure this is the correct primary key field for the users table.
        }
      }
    },
    {
      sequelize,
      tableName: "projects",  // Table names are generally lowercase.
      timestamps: false
    }
  );

  return Project;
};
