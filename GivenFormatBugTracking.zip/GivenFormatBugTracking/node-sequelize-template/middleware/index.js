const Socket = require('./Socket');
const Authentication = require('./Authentication');

module.exports = {
  Socket,
  Authentication
};
