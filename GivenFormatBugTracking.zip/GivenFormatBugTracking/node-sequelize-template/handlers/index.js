const UserHandler = require('./UserHandler');


module.exports = {
  UserHandler,
};
