module.exports = {
    AUTH_SECRET_KEY: 'secret',
    AUTH_EXPIRE_TIME: '1h'
}